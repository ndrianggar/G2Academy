

var artikel1 = {
    gambar: "Jakarta.jpg",
    judul1: "Belajar dari pengajar yang berpengalaman dan berdedikasi di bidangnya",
    isiartikel1: "Dapatkan pengalaman belajar bersama instruktur senior yang penuh semangat dan dedikasi. Merekalah yang telah mendorong perusahaan-perusahaan teknologi saat ini berkembang dengan pesat. Instruktur kami memberikan pengalaman kelas yang sangat berbeda, dirancang secara khusus, serta terhubung dengan dunia nyata. Utamanya, mereka berkomitmen kepada anda sebagai seorang individu pembelajar."

};

var Artikel2 = {
    gambar: "Jakarta.jpg",
    judul: "Belajar dari pengajar yang berpengalaman dan berdedikasi di bidangnya",
    isiartikel2: "Dapatkan pengalaman belajar bersama instruktur senior yang penuh semangat dan dedikasi.Merekalah yang telah mendorong perusahaan - perusahaan teknologi saat ini berkembang dengan pesat.Instruktur kami memberikan pengalaman kelas yang sangat berbeda, dirancang secara khusus, serta terhubung dengan dunia nyata.Utamanya, mereka berkomitmen kepada anda sebagai seorang individu pembelajar."


};


var list = "<p>" + Artikel1.isiartikel1.join("</p>") + "";


document.getElementById('judul1').innerHTML = artikel1.judul1;
document.getElementById('isiartikel1').innerHTML = artikel1.isiartikel1;
document.getElementById('gambar1').innerHTML = artikel1.gambar1;
document.getElementById('isiartikel1').innerHTML = list;





document.getElementById('tRubah').onclick = function () {
    document.getElementById('judul2').innerHTML = Artikel12.judul2;
    document.getElementById('isiartikel2').innerHTML = Artikel12.isiartikel2;
    document.getElementById('gambar2').innerHTML = Artikel12.gambar2;

}

document.getElementById('tBack').ondblclick = function () {
    alert("pelan-pelan mas tekannya hanya sekali");

}



// Get the elements with class="column"
var elements = document.getElementsByClassName("column");

// Declare a loop variable
var i;


function one() {
    for (i = 0; i < elements.length; i++) {
        elements[i].style.msFlex = "100%";  // IE10
        elements[i].style.flex = "100%";
    }
}


function two() {
    for (i = 0; i < elements.length; i++) {
        elements[i].style.msFlex = "50%";  // IE10
        elements[i].style.flex = "50%";
    }
}
